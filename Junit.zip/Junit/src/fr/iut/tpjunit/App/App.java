package fr.iut.tpjunit.App;

public class App {

	public static int sum(int param1, int param2) {
		// TODO Auto-generated method stub
		return param1+param2;
	}
	public static int addition(int param1, int param2) {
	
		return param1+param2;
	}
	public static int multiplication(int param1, int param2) {
		
		return param1*param2;
	}
	public static int division(int param1, int param2) {
		
		return param1/param2;
	}
	public static int multi(){
		return 0;
	}
	
}
